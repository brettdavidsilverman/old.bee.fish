# bee.fish
Files to create bee.fish website

This contains all the files used to research and design https://bee.fish

The files under /cgi are used to create an actual https server.
Use the make command under /cgi to build the C++ examples
Use Node.js to run the simple javascript server.js

The rest of the files are html or js and provide examples of what I've been researching.

