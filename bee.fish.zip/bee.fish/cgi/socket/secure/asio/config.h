#define KEY_FILE "/etc/letsencrypt/live/bee.fish/privkey.pem"
#define CERT_FILE "/etc/letsencrypt/live/bee.fish/fullchain.pem"