function load(script) {
   alert(script.innerHTML);
}