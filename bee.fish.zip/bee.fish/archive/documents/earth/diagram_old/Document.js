function Document(inputs) {
	var outputs = new Outputs();
	
	outputs.document = window.document;
	return outputs;
	
}
