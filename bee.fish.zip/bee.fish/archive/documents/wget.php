<?php 
    echo `wget http://www.hotmail.com`; 
?>