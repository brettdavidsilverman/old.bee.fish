#include <iostream>
using namespace std;
/*
unsigned long long i;
void f(void);
void f(void) {
    i++;
    f();
    return;
}
int main(char argc, char* args[]) {

    i = 0;
    try {
        f();
    } catch(...) {
    }

    cout << i << endl;

    return 0;
}
*/