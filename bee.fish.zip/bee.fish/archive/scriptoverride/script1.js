var canvas = {
  id: "script1"
}