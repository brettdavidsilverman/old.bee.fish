var five = {
   toString: function() {
      return "five object";
   }
}
alert("script");